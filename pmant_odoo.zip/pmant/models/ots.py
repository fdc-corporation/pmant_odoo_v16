from odoo import models, fields, api
#import pdfkit
#from odoo.addons.payment.models.payment_acquirer import ValidationError
from odoo.exceptions import ValidationError
import smtplib
from dateutil.relativedelta import relativedelta
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders

class OTS(models.Model):
    _inherit    = 'maintenance.request'
    # _name       = 'maintenance.request'

    tarea = fields.Many2one('tarea.mantenimiento', string='Tarea')
    estado = fields.Boolean(related="tarea.revisar", string="Estado")
    # tex = fields.Char(compute="_get_tex", string='Text')
    tex = fields.Char(string='Text')
    empresa = fields.Many2one('res.partner', related="tarea.cliente")
    ubicacion = fields.Many2one('res.partner', related="tarea.ubicacion")

    @api.depends('estado')
    def _get_tex(self):
        if self.estado == True:
            self.tex = "Urgente"

    @api.onchange('stage_id')
    def _change_createui(self):
        for record in self:
            if self.tarea:
                if self.stage_id.id == 3:
                    self.env.cr.execute("UPDATE tarea_mantenimiento SET create_uid = 1 WHERE id = "+str(self.tarea.id))
    
    def send_sms(self,destino):
        data = {
           'doc':self
        }
        ICPSudo = self.env['ir.config_parameter'].sudo()
        url_base = ICPSudo.get_param('pmant.ruta_web')
        remitente = ICPSudo.get_param('pmant.correo')
        clave_correo = ICPSudo.get_param('pmant.clave_correo')
        server_smtp = ICPSudo.get_param('pmant.smtp')
        if not remitente:
            raise ValidationError("Configure un correo")
        if not url_base:
            raise ValidationError("Configure la url base / dominio")


        #pdf = pdfkit.from_url(str(url_base)+'/reporte2?id='+str(self.id), False)

        msg2 = MIMEMultipart()
        msg2['From'] = remitente
        msg2['To'] = destino
        msg = '<p>Descargue  el archivo adjunto o ' \
                          'ingrese al siguiente enlace :' \
                          ' <a href="'+str(url_base)+'/reporte?id='+str(self.id)+'">Ver Reporte</a> </p>'
        msg2['Subject'] = " Reporte: "+str(self.tarea.name)
        msg2.attach(MIMEText(msg, 'html', 'utf-8'))
        #msg2.attach(MIMEText(msg, 'plain'))
        
        # Creamos un objeto MIME base
        #adjunto_MIME = MIMEBase('application', 'octet-stream')
        # Y le cargamos el archivo adjunto
        #adjunto_MIME.set_payload(pdf)
        # Codificamos el objeto en BASE64
        #encoders.encode_base64(adjunto_MIME)
        # Agregamos una cabecera al objeto
        #adjunto_MIME.add_header('Content-Disposition', "attachment; filename= %s" % 'reporte'+str(self.tarea.name)+'.pdf')
        # Y finalmente lo agregamos al mensaje
        #msg2.attach(adjunto_MIME)

        server = smtplib.SMTP(server_smtp, 587)
        server.starttls()
        server.login(remitente, clave_correo)
        server.sendmail(remitente, destino, msg2.as_string())
        server.quit()

    def send_report_empresa(self):
        destino_empresa = self.empresa.email
        if destino_empresa:
            self.send_sms(destino_empresa)
        else:
            raise ValidationError("La empresa no tiene un correo")

    def send_report_sucursal(self):
        destino_sucursal = self.ubicacion.email
        if destino_sucursal:
            self.send_sms(destino_sucursal)
        else:
            raise ValidationError("La Sucursal no tiene un correo") 
