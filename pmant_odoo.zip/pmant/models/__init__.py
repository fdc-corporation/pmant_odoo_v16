# -*- coding: utf-8 -*-
from . import equipo
from . import  herencia
from . import ots
from . import plan
from . import planequipo
from .  import proceso
from . import plantilla
from . import tarea
from . import adjuntos
from . import parametros
