# -*- coding: utf-8 -*-
from odoo import models, fields, api
from odoo.http import request
import qrcode
import base64
from io import BytesIO

from dateutil.relativedelta import relativedelta
#import cStringIO
#funcion generica para  generar QR
#clase prioridad

#clase equipo



