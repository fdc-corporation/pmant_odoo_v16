#!/bin/bash
docker stop $1
docker start $1
docker  exec -ti -u 0 $1 service odoo restart
