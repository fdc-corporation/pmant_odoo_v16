#!/bin/bash
 git add .
 git commit -m $1
 git push -uf pmant  master:rama1

