from odoo import models, fields, api, exceptions
from datetime import datetime, timedelta
import logging

_logger = logging.getLogger(__name__)


class TipoTarea(models.Model):
    _name = 'tipotarea.mantenimiento'
    name = fields.Char(size=25, required=True, string='Nombre')


class Tarea(models.Model):
    _name = 'tarea.mantenimiento'
    name = fields.Char(size=60, required=True, string='Nombre', write=['pmant.group_pmant_admin'])
    tipo = fields.Many2one('tipotarea.mantenimiento', string="Tipo")
    cliente = fields.Many2one('res.partner', string="Cliente", domain=[('is_company', '=', True)], required=False)
    ubicacion = fields.Many2one('res.partner', string="Ubicacion")
    planequipo = fields.One2many('planequipo.mantenimiento', 'tarea', string='Equipo / Plan', required=True)
    clasi1 = fields.Char(size=50, string="Clasificacion 1")
    clasi2 = fields.Char(size=50, string="Clasificacion 2")
    prioridad = fields.Selection(related="ots.priority")
    adjunto = fields.Binary()
    ots = fields.One2many('maintenance.request', 'tarea', string="ots")
    procesos = fields.One2many('planequipoproceso.mantenimiento', 'tarea', string="Estado de  Procesos")
    state_id = fields.Many2one('maintenance.stage', string="Etapa", store=True)
    revisar = fields.Boolean()
    archive = fields.Boolean(related="ots.archive", stored=True)
    namefirma = fields.Char(string="Nombre del Firmante")
    dni = fields.Char(string="DNI del Firmante")
    is_admin = fields.Boolean(compute="_is_admin", default=True)
    comentario = fields.Text('Comentario del firmante')

    def revisar_act(self):
        self.revisar = True

    def anular_act(self):
        self.revisar = False

    @api.onchange('state_id')
    def _change_stado(self):
        for line in self.ots:
            line.stage_id = self.state_id

        if self.state_id.id == 7:
            for re in self.planequipo:
                now = fields.Date.today()
                fecha_prox = now + timedelta(days=(re.plan.frecuencia * re.plan.tipo.dias))
                re.write({'fecha_ejec': now})

                ids = []
                acc = self.env['ir.model.data']._xmlid_to_res_id('pmant.group_recibir_notificacion')
                gr = self.env['res.groups'].browse(int(acc))
                for r in gr.users:
                    if r.partner_id.email:
                        ids.append(r.partner_id.id)
                if not ids:
                    raise exceptions.UserError('No hay configurado Usuarios para que adjunten un Pago')

                ubicacion_calendario = self.ubicacion.name
                h = self.env['calendar.event'].create({
                    'name': 'Proximo Mantenimiento , Equipo: ' + str(re.equipo.name),
                    'start': fecha_prox,
                    'stop': fecha_prox,
                    'partner_ids': [(6, 0, ids)],
                    'location': ubicacion_calendario,
                })
                ci = h.id
                for ai in re.plan.alarm_ids:
                    self.env.cr.execute(
                        "INSERT INTO  calendar_alarm_calendar_event_rel (calendar_event_id,calendar_alarm_id) values (%s, %s)",
                        (ci, ai.id))

    @api.model
    def enviar_alerta(self):
        d = 5

    def _is_admin(self):
        self.is_admin = self.env.user.has_group('pmant.group_pmant_admin')
