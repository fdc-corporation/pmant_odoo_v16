from odoo import models, fields

class Adjunto(models.Model):
    _name = 'adjunto.mantenimiento'
    name = fields.Char(string='Referencia Archivo', size=60)
    adjunto = fields.Binary()
    equipo = fields.Many2one('maintenance.equipment', string='Equipo')

class AdjuntoImage(models.Model):
    _name = 'adjuntoimage.mantenimiento'
    name = fields.Char(string='Referencia Archivo', size=60)
    adjunto = fields.Binary()
    planequipoproceso = fields.Many2one('planequipoproceso.mantenimiento')
    comentario = fields.Text()
