from odoo import models, fields

class FrecuenciaPlan(models.Model):
    _name = 'tipoplan.mantenimiento'

    name = fields.Char(string='Nombre', required=True, size=25)
    dias = fields.Integer(string='Equivalencia en N° de Días', required=True)

class Plan(models.Model):
    _name = 'plan.mantenimiento'

    name = fields.Char(string='Nombre', required=True, size=60)
    frecuencia = fields.Integer(string="Unidad Frecuencia", required=True)
    tipo = fields.Many2one('tipoplan.mantenimiento', string="Tipo Frecuencia")
    proceso = fields.One2many('proceso.mantenimiento', 'plan', string="procesos")
    descripcion = fields.Text()
    aviso_dias = fields.Integer(string="Días de Aviso", default=1)
    alarm_ids = fields.Many2many('calendar.alarm', string="Recordatorios")
