from odoo import models, fields, api

class Contacto(models.Model):
    _inherit = 'res.partner'

    equipos = fields.One2many('maintenance.equipment', 'propietario', string="Equipos de Mantenimiento")

    @api.onchange('street')
    def _change_stree(self):
        if not self.name:
            self.name = 'Escribir aqui'

class Empleado(models.Model):
    _inherit = 'hr.employee'

    firma = fields.Binary()
    dni = fields.Char(string="N° Documento para la firma")
