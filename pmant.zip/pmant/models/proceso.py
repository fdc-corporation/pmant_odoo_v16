from odoo import models, fields


class PlanEquipoProcesos(models.Model):
    _name = 'planequipoproceso.mantenimiento'

    proceso = fields.Many2one('proceso.mantenimiento', string="Proceso", required=True)
    planequipo = fields.Many2one('planequipo.mantenimiento', string='Plan Equipo')
    descripcion = fields.Text(string="Comentarios")
    descripcion_proceso = fields.Text(related="proceso.descripcion")
    estado = fields.Many2one('estadoproceso.mantenimiento', string="Estado", required=True)
    tarea = fields.Many2one('tarea.mantenimiento', string="Tarea")
    ots = fields.Many2one('maintenance.request', string="ots")
    plan = fields.Many2one('plan.mantenimiento', related="planequipo.plan")
    adjunto = fields.Binary(string="Adjunto 1")
    adjunto2 = fields.Binary(compute="_get_adjunto", string="Adjunto 2")
    is_admin = fields.Boolean(compute="_get_adjunto")
    descripcion2 = fields.Text(compute="_get_adjunto", default="falta poner Comentario...", string="Comentarios")
    name_file = fields.Char(default="Adjunto")
    adjuntos = fields.One2many('adjuntoimage.mantenimiento', 'planequipoproceso', string="Archivos Adjuntos")

    def _get_adjunto(self):
        for rec in self:
            rec.is_admin = self.env.user.has_group('pmant.group_pmant_admin')
            rec.adjunto2 = rec.adjunto
            txt = rec.descripcion or ''
            if len(txt) > 50:
                txt = txt[:50] + '...'
            rec.descripcion2 = txt if txt else 'falta poner Comentario...'


class GrupoParte(models.Model):
    _name = 'grupoproceso.mantenimiento'
    name = fields.Char(size=60, required=True, string='Nombre')


class Proceso(models.Model):
    _name = 'proceso.mantenimiento'

    name = fields.Char(size=60, required=True, string='Nombre')
    grupo = fields.Many2one('grupoproceso.mantenimiento', string="Grupo/Parte")
    plan = fields.Many2one('plan.mantenimiento')
    descripcion = fields.Text()


class EstadoProceso(models.Model):
    _name = 'estadoproceso.mantenimiento'
    name = fields.Char(size=5, required=True, string='Nombre')
