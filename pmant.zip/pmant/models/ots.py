from odoo import models, fields, api
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

class OTS(models.Model):
    _inherit = 'maintenance.request'

    tarea = fields.Many2one('tarea.mantenimiento', string='Tarea')
    estado = fields.Boolean(related="tarea.revisar", string="Estado")
    tex = fields.Char(string='Text')
    empresa = fields.Many2one('res.partner', related="tarea.cliente")
    ubicacion = fields.Many2one('res.partner', related="tarea.ubicacion")

    @api.depends('estado')
    def _get_tex(self):
        for record in self:
            record.tex = "Urgente" if record.estado else ""

    @api.onchange('stage_id')
    def _change_createui(self):
        if self.tarea and self.stage_id.id == 3:
            self.env.cr.execute("UPDATE tarea_mantenimiento SET create_uid = 1 WHERE id = %s", (self.tarea.id,))

    def send_sms(self, destino):
        ICPSudo = self.env['ir.config_parameter'].sudo()
        url_base = ICPSudo.get_param('pmant.ruta_web')
        remitente = ICPSudo.get_param('pmant.correo')
        clave_correo = ICPSudo.get_param('pmant.clave_correo')
        server_smtp = ICPSudo.get_param('pmant.smtp')
        if not remitente:
            raise ValidationError("Configure un correo")
        if not url_base:
            raise ValidationError("Configure la url base / dominio")

        msg = MIMEMultipart()
        msg['From'] = remitente
        msg['To'] = destino
        msg['Subject'] = "Reporte: {}".format(self.tarea.name)

        body = '<p>Descargue el archivo adjunto o ingrese al siguiente enlace: ' \
               '<a href="{}/reporte?id={}">Ver Reporte</a></p>'.format(url_base, self.id)

        msg.attach(MIMEText(body, 'html'))

        server = smtplib.SMTP(server_smtp, 587)
        server.starttls()
        server.login(remitente, clave_correo)
        server.sendmail(remitente, destino, msg.as_string())
        server.quit()

    def send_report_empresa(self):
        destino_empresa = self.empresa.email
        if destino_empresa:
            self.send_sms(destino_empresa)
        else:
            raise ValidationError("La empresa no tiene un correo")

    def send_report_sucursal(self):
        destino_sucursal = self.ubicacion.email
        if destino_sucursal:
            self.send_sms(destino_sucursal)
        else:
            raise ValidationError("La Sucursal no tiene un correo")
