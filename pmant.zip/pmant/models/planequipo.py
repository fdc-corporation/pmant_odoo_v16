from odoo import models, fields, api
from datetime import date, datetime, timedelta

class PlanEquipo(models.Model):
    _name          = 'planequipo.mantenimiento'

    name           = fields.Char(compute='_generate_name')
    plan           = fields.Many2one('plan.mantenimiento',string='Plan de Tarea',required=True)
    equipo         = fields.Many2one('maintenance.equipment',string='Equipo',required=True)
    ubicacion      = fields.Many2one('res.partner',string='Ubicacion')
    tarea          = fields.Many2one('tarea.mantenimiento',string='Tarea',required=True)
    ots            = fields.One2many('maintenance.request','tarea',related="tarea.ots")
    procesos       = fields.One2many('planequipoproceso.mantenimiento','planequipo' , string="Procesos a Utilizar")
    fecha_ejec     = fields.Date(string="Fecha")
    is_admin       = fields.Boolean(compute="_generate_tecnico", default=True)
    creador_id     = fields.Integer(compute="_generate_tecnico")
    fecha_ejecprox = fields.Date(compute="_generate_tecnico", store=True)
    # is_admin       = fields.Boolean(default=True, string="Es Admin")
    # creador_id     = fields.Integer(string="Creado")
    # fecha_ejecprox = fields.Date(stored=True, string="Fecha ejec")

    avisado        = fields.Boolean(default=False)

    #'''
    def _generate_tecnico(self):
        self.creador_id=self.equipo.create_uid
        self.is_admin = self.env['res.users'].has_group('pmant.group_pmant_admin')
        if self.fecha_ejec != False:
            fecha_prox      =  datetime.strptime(str(self.fecha_ejec), '%Y-%m-%d')
            fecha_prox      = fecha_prox + timedelta(days=(self.plan.frecuencia*self.plan.tipo.dias))
            self.fecha_ejecprox = str(fecha_prox)

    def _generate_name(self):
        for record in self:
            f = record.fecha_ejec
            if f == False:
                fechaj=" - EN PROCESO"
            else:
                fechaj = " - "+str(f)
            record.name = str(record.equipo.name)+" - "+str(record.plan.name)+fechaj
            
    @api.onchange('plan')
    def _onchange_procesos(self):
        self.procesos  = False
        for record in self.plan.proceso:
            self.procesos += self.env['planequipoproceso.mantenimiento'].new({'proceso': record.id,'planequipo':self.id,'tarea':self.tarea,'plan':self.plan})
    #'''
