from odoo import models, fields, api
from datetime import datetime, timedelta

class PlanEquipo(models.Model):
    _name = 'planequipo.mantenimiento'

    name = fields.Char(compute='_generate_name', store=True)
    plan = fields.Many2one('plan.mantenimiento', string='Plan de Tarea', required=True)
    equipo = fields.Many2one('maintenance.equipment', string='Equipo', required=True)
    ubicacion = fields.Many2one('res.partner', string='Ubicación')
    tarea = fields.Many2one('tarea.mantenimiento', string='Tarea', required=True)
    ots = fields.One2many('maintenance.request', 'tarea', related="tarea.ots")
    procesos = fields.One2many('planequipoproceso.mantenimiento', 'planequipo', string="Procesos a Utilizar")
    fecha_ejec = fields.Date(string="Fecha")
    is_admin = fields.Boolean(compute="_generate_tecnico", default=True)
    creador_id = fields.Many2one('res.users', compute="_generate_tecnico", store=True)
    fecha_ejecprox = fields.Date(compute="_generate_tecnico", store=True)
    avisado = fields.Boolean(default=False)

    @api.depends('equipo')
    def _generate_tecnico(self):
        for record in self:
            record.creador_id = record.equipo.create_uid
            record.is_admin = self.env.user.has_group('pmant.group_pmant_admin')
            if record.fecha_ejec:
                fecha_prox = datetime.strptime(str(record.fecha_ejec), '%Y-%m-%d') + timedelta(days=(record.plan.frecuencia * record.plan.tipo.dias))
                record.fecha_ejecprox = fecha_prox.strftime('%Y-%m-%d')

    @api.depends('fecha_ejec')
    def _generate_name(self):
        for record in self:
            fechaj = " - EN PROCESO" if not record.fecha_ejec else " - " + str(record.fecha_ejec)
            record.name = f"{record.equipo.name} - {record.plan.name}{fechaj}"

    @api.onchange('plan')
    def _onchange_procesos(self):
        self.procesos = [(5, 0, 0)]
        self.procesos = [(0, 0, {'proceso': proceso.id, 'planequipo': self.id, 'tarea': self.tarea.id, 'plan': self.plan.id}) for proceso in self.plan.proceso]
