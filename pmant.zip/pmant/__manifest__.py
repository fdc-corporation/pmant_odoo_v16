# -*- coding: utf-8 -*-
{
    'name': "FDC CORP",

    'summary': """
            Modulo para Fdcorp""",

    'description': """
        Long description of module's purpose
    """,

    'author': "My Company",
    'website': "http://www.yourcompany.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/11.0/odoo/addons/base/module/module_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base','mail','maintenance','hr','contacts','hr_maintenance','web_digital_sign','calendar'],

    # always loaded
    'data': [
        'security/security.xml',
        'security/ir.model.access.csv',
        'views/views.xml',
        'views/templates.xml',
        'views/general.xml',
        'views/herencia.xml',
        'views/reporteots.xml',
        'views/reportetecnico.xml',
        'views/reporteequipo.xml',
        'views/configuracion.xml',
        'views/wizard.xml',
        'views/reportecertificado.xml',
        'views/reporteticket.xml',
        'views/equipos.xml',
        'views/rules_cliente.xml',
        'views/rules_cliente_empresa.xml',
        'views/rules_tecnico.xml',
        'views/res_partner.xml',
        'views/adjuntos.xml',
        'views/planequipo.xml',
        'views/planequipoproceso.xml',
        'views/reportetecnico_multi.xml',
        'views/reporteots_multi.xml',
        'views/ots.xml',
        'views/paramatros.xml',
        'data/ir_module_category_data.xml',
        'views/reporteweb.xml',
        'views/planequipo_reporte.xml'
    ],
    # only loaded in demonstration mode
    'demo': [
        'demo/demo.xml',
    ],
    #'css': [
    #"    'static/src/css/jesus.css',
    #],

}

