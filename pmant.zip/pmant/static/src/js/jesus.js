odoo.define('website.website',function(require){
 "use strict";
  alert('hola');

})
